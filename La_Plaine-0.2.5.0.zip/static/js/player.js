/**
 * Contrôles et état du joueur : déplacement, collisions, inventaire et interactions.
 * Les vitesses et les forces sont exprimées par seconde ; la boucle principale
 * fournit un delta borné pour limiter les téléportations après une pause d'onglet.
 */



const INVENTORY_SIZE = 36;
const HOTBAR_SIZE = 9;
const STACK_LIMIT = 100;
const itemDefinition = id => window.itemsRegistry?.get(id) || null;
const stackLimitFor = id => itemDefinition(id)?.stack || STACK_LIMIT;


function applyBlockIcon(el, def) {
    const t = def && def.textures;
    const url = t ? (t.all || t.sides || t.top || '') : '';
    if (url) {
        el.style.backgroundImage = `url('${url}')`;
        el.style.backgroundSize = '68%';
        el.style.backgroundRepeat = 'no-repeat';
        el.style.backgroundPosition = 'center';
        el.style.imageRendering = 'pixelated';
    } else {
        el.style.backgroundImage = '';
    }
    return !!url;
}

class Inventory {
    constructor() {
        this.slots = Array.from({ length: INVENTORY_SIZE }, () => ({ type: 0, count: 0 }));
        this.selectedSlotIndex = 0;
        this.isOpen = false;
        this.onChange = null;
    }

    getSelectedSlot() {
        return this.slots[this.selectedSlotIndex];
    }

    serialize() {
        return this.slots.map(slot => ({
            type: Number(slot?.type) || 0,
            count: Number(slot?.count) || 0
        }));
    }

    deserialize(slots) {
        if (!Array.isArray(slots) || slots.length !== INVENTORY_SIZE) return false;
        this.slots = slots.map(slot => {
            const rawType = Number(slot?.type);
            const type = Number.isSafeInteger(rawType) && rawType > 0 ? rawType : 0;
            const count = Math.max(0, Math.min(stackLimitFor(type), Math.floor(Number(slot?.count) || 0)));
            return count > 0 && type > 0 ? { type, count } : { type: 0, count: 0 };
        });
        this.updateUI();
        return true;
    }

    selectSlot(index) {
        if (index >= 0 && index < HOTBAR_SIZE) {
            this.selectedSlotIndex = index;
            if (typeof soundManager !== 'undefined' && soundManager?.playSelectSlot) {
                soundManager.playSelectSlot();
            }
            this.updateUI();
        }
    }

    canAdd(itemId, amount = 1) {
        const def = itemDefinition(itemId);
        const cap = def?.stack || STACK_LIMIT;
        let space = 0;
        for (const slot of this.slots) {
            if (slot.type === itemId) space += Math.max(0, cap - slot.count);
            else if (!slot.type) space += cap;
        }
        return space >= amount;
    }

    addItem(itemId, amount = 1) {
        itemId = Number(itemId);
        if (!Number.isSafeInteger(itemId) || itemId <= 0 || amount <= 0) return amount;
        const cap = stackLimitFor(itemId);
        let remaining = Math.floor(amount);
        for (const slot of this.slots) {
            if (slot.type === itemId && slot.count < cap && remaining > 0) {
                const take = Math.min(cap - slot.count, remaining);
                slot.count += take; remaining -= take;
            }
        }
        for (const slot of this.slots) {
            if (!slot.type && remaining > 0) {
                const take = Math.min(cap, remaining);
                slot.type = itemId; slot.count = take; remaining -= take;
            }
        }
        this.updateUI();
        return remaining;
    }

    addBlock(blockId, amount = 1) { return this.addItem(blockId, amount); }

    useSelectedBlock() {
        const current = this.getSelectedSlot();
        if (current && current.type !== 0 && current.count > 0) {
            current.count--;
            const placedType = current.type;
            if (current.count === 0) {
                current.type = 0;
            }
            this.updateUI();
            return placedType;
        }
        return null;
    }

    swapSlots(indexA, indexB) {
        if (indexA === indexB || indexA < 0 || indexA >= INVENTORY_SIZE || indexB < 0 || indexB >= INVENTORY_SIZE) {
            return;
        }

        const a = this.slots[indexA];
        const b = this.slots[indexB];

        if (a.type !== 0 && a.type === b.type) {
            const space = stackLimitFor(b.type) - b.count;
            const toMove = Math.min(space, a.count);
            b.count += toMove;
            a.count -= toMove;
            if (a.count === 0) a.type = 0;
        } else {
            this.slots[indexA] = b;
            this.slots[indexB] = a;
        }

        this.updateUI();
    }

    toggleOpen() {
        this.isOpen = !this.isOpen;
        this.updateUI();
        return this.isOpen;
    }

    close() {
        if (this.isOpen) {
            this.isOpen = false;
            this.updateUI();
        }
    }

    updateUI() {
        for (let i = 0; i < HOTBAR_SIZE; i++) {
            const slotEl = document.getElementById(`slot-${i}`);
            if (!slotEl) continue;

            const nameEl = slotEl.querySelector('.slot-name');
            const countEl = slotEl.querySelector('.slot-count');

            slotEl.classList.toggle('active', i === this.selectedSlotIndex);

            const slot = this.slots[i];
            if (slot && slot.type !== 0 && slot.count > 0) {
                const itemObj = itemDefinition(slot.type);
                const blockObj = typeof blockRegistry !== 'undefined' ? blockRegistry.get(slot.type) : null;
                const hasIcon = itemObj?.texture ? (slotEl.style.backgroundImage = `url('${itemObj.texture}')`, true) : applyBlockIcon(slotEl, blockObj);
                slotEl.title = itemObj?.name || blockObj?.name || 'Objet';
                if (nameEl) nameEl.textContent = hasIcon ? '' : (itemObj?.name || blockObj?.name || 'Objet');
                if (countEl) countEl.textContent = slot.count;
            } else {
                applyBlockIcon(slotEl, null);
                slotEl.title = '';
                if (nameEl) nameEl.textContent = '';
                if (countEl) countEl.textContent = '';
            }
        }

        if (typeof this.onChange === 'function') {
            this.onChange(this);
        }
    }
}

class Player {
    constructor(camera, domElement, world) {
        this.camera = camera;
        this.world = world;

        const ControlsClass = THREE.PointerLockControls || window.PointerLockControls;
        if (typeof ControlsClass === 'function') {
            this.controls = new ControlsClass(camera, domElement);
        } else {
            console.error("PointerLockControls n'a pas été trouvé.");
        }

        this.inventory = new Inventory();

        
        this.maxHealth = 10;
        this.health = 10;
        this.dead = false;
        this.invulnerableUntil = 0;

        this.width = 0.6;
        this.height = 1.8;
        this.eyeHeight = 1.62;

        this.position = new THREE.Vector3(0.5, 100, 0.5);
        this.velocity = new THREE.Vector3();

        this.lookDir = new THREE.Vector3();
        this.pivot = new THREE.Vector3();
        this.desiredPos = new THREE.Vector3();
        this.testPoint = new THREE.Vector3();
        this.forward = new THREE.Vector3();
        this.side = new THREE.Vector3();
        this.upVector = new THREE.Vector3(0, 1, 0);
        this.moveVector = new THREE.Vector3();
        this.tempRayPos = new THREE.Vector3();

        this.moveForward = false;
        this.moveBackward = false;
        this.moveLeft = false;
        this.moveRight = false;
        this.canJump = false;
        this.spaceHeld = false;

        
        this.walkSpeed = 4.3;
        this.sprintSpeed = 7.5;
        this.speed = this.walkSpeed;
        this.isSprinting = false;

        this.jumpForce = 8.5;
        this.gravity = 28.0;

        this.stepTimer = 0;
        this.walkCycle = 0;
        this.attackSwing = 0;
        this.fallPeakY = this.position.y;
        this.playerParts = null;
        
        
        this.cameraMode = 0;
        this.thirdPersonDistance = 3.5;

        this.isReady = false;

        this.initMeshPlayer();
        this.initControls();
        this.updateCameraPosition();
        this.updateHealthUI();
    }

    serializeState() {
        return {
            x: this.position.x, y: this.position.y, z: this.position.z,
            rot_x: this.camera.rotation.x, rot_y: this.camera.rotation.y,
            health: this.health,
            selected_slot: this.inventory.selectedSlotIndex,
            camera_mode: this.cameraMode,
            velocity_x: this.velocity.x, velocity_y: this.velocity.y, velocity_z: this.velocity.z,
            inventory: this.inventory.serialize()
        };
    }

    restoreState(state, options = {}) {
        if (!state) return false;
        const full = options.full !== false;
        const n = Number;
        if ([state.x, state.y, state.z].every(v => Number.isFinite(n(v)))) {
            this.position.set(n(state.x), n(state.y), n(state.z));
        }
        if (Number.isFinite(n(state.rot_x)) && Number.isFinite(n(state.rot_y))) {
            this.camera.rotation.set(n(state.rot_x), n(state.rot_y), 0);
        }
        if (Number.isFinite(n(state.velocity_x)) && Number.isFinite(n(state.velocity_y)) && Number.isFinite(n(state.velocity_z))) {
            this.velocity.set(n(state.velocity_x), n(state.velocity_y), n(state.velocity_z));
        }
        if (full) {
            if (Number.isFinite(n(state.health))) {
                this.health = Math.max(0, Math.min(this.maxHealth, n(state.health)));
                this.dead = this.health <= 0;
                const deathOverlay = document.getElementById('death-overlay');
                if (deathOverlay) deathOverlay.style.display = this.dead ? 'flex' : 'none';
            }
            if (Number.isInteger(Number(state.selected_slot))) {
                this.inventory.selectedSlotIndex = Math.max(0, Math.min(HOTBAR_SIZE - 1, Number(state.selected_slot)));
            }
            if (Number.isInteger(Number(state.camera_mode))) {
                this.cameraMode = Math.max(0, Math.min(2, Number(state.camera_mode)));
            }
            this.inventory.deserialize(state.inventory);
            // La visibilité du modèle doit suivre le mode restauré, y compris après
            // rechargement du monde (sinon le skin apparaît/disparaît au mauvais moment).
            if (this.playerGroup) this.playerGroup.visible = (this.cameraMode !== 0);
            this.updateHealthUI();
        }
        this.fallPeakY = this.position.y;
        this.updateCameraPosition();
        return true;
    }

    triggerAttack() {
        // Déclenche une animation de coup visible en vue à la troisième personne.
        this.attackSwing = 1;
    }

    updateHealthUI() {
        const container = document.getElementById('health-container');
        if (!container) return;

        container.innerHTML = '';
        for (let i = 0; i < this.maxHealth; i++) {
            const heart = document.createElement('div');
            heart.className = 'heart-icon';
            if (i >= this.health) {
                heart.style.opacity = '0.25';
            }
            container.appendChild(heart);
        }
    }

    takeDamage(amount) {
        if (this.dead || performance.now() < this.invulnerableUntil) return;
        this.health = Math.max(0, this.health - Math.max(0, amount));
        this.invulnerableUntil = performance.now() + 700;
        if (window.soundManager?.playHurt) window.soundManager.playHurt(amount);
        const vignette = document.getElementById('damage-vignette');
        if (vignette && localStorage.getItem('fxDamageVignette') !== 'false') {
            vignette.classList.remove('active'); void vignette.offsetWidth; vignette.classList.add('active');
        }
        this.updateHealthUI();
        window.dispatchEvent(new Event('health-changed'));
        if (this.health <= 0) {
            this.dead = true;
            const overlay = document.getElementById('death-overlay');
            if (overlay) overlay.style.display = 'flex';
            if (this.controls?.isLocked) this.controls.unlock();
        }
    }

    heal(amount) {
        this.health = Math.min(this.maxHealth, this.health + amount);
        if (this.health > 0) this.dead = false;
        this.updateHealthUI();
        window.dispatchEvent(new Event('health-changed'));
    }

    getAABB() {
        const halfWidth = this.width / 2;
        return {
            min: new THREE.Vector3(this.position.x - halfWidth, this.position.y, this.position.z - halfWidth),
            max: new THREE.Vector3(this.position.x + halfWidth, this.position.y + this.height, this.position.z + halfWidth)
        };
    }

    extractFaceTexture(image, x, y, w, h) {
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.imageSmoothingEnabled = false;
        ctx.drawImage(image, x, y, w, h, 0, 0, w, h);

        const tex = new THREE.CanvasTexture(canvas);
        tex.magFilter = THREE.NearestFilter;
        tex.minFilter = THREE.NearestFilter;
        tex.needsUpdate = true;
        return tex;
    }

    createBoxMaterials(img, u, v, w, h, d) {
        const texRight = this.extractFaceTexture(img, u, v + d, d, h);
        const texLeft  = this.extractFaceTexture(img, u + d + w, v + d, d, h);
        const texTop   = this.extractFaceTexture(img, u + d, v, w, d);
        const texBot   = this.extractFaceTexture(img, u + d + w, v, w, d);
        const texFront = this.extractFaceTexture(img, u + d, v + d, w, h);
        const texBack  = this.extractFaceTexture(img, u + d + w + d, v + d, w, h);

        const makeMat = (tex) => new THREE.MeshLambertMaterial({ map: tex, transparent: true, alphaTest: 0.1 });

        return [
            makeMat(texRight),
            makeMat(texLeft),
            makeMat(texTop),
            makeMat(texBot),
            makeMat(texFront),
            makeMat(texBack)
        ];
    }

    initMeshPlayer() {
        this.playerGroup = new THREE.Group();

        const img = new Image();
        img.onload = () => {
            const rightLegGeo = new THREE.BoxGeometry(0.24, 0.75, 0.24);
            const rightLegMat = this.createBoxMaterials(img, 0, 16, 4, 12, 4);
            const rightLeg = new THREE.Mesh(rightLegGeo, rightLegMat);
            rightLeg.position.set(0.12, 0.375, 0);

            const leftLegGeo = new THREE.BoxGeometry(0.24, 0.75, 0.24);
            const leftLegMat = this.createBoxMaterials(img, 16, 48, 4, 12, 4);
            const leftLeg = new THREE.Mesh(leftLegGeo, leftLegMat);
            leftLeg.position.set(-0.12, 0.375, 0);

            const bodyGeo = new THREE.BoxGeometry(0.48, 0.75, 0.24);
            const bodyMat = this.createBoxMaterials(img, 16, 16, 8, 12, 4);
            const body = new THREE.Mesh(bodyGeo, bodyMat);
            body.position.set(0, 1.125, 0);

            const rightArmGeo = new THREE.BoxGeometry(0.24, 0.75, 0.24);
            const rightArmMat = this.createBoxMaterials(img, 40, 16, 4, 12, 4);
            const rightArm = new THREE.Mesh(rightArmGeo, rightArmMat);
            rightArm.position.set(0.36, 1.125, 0);

            const leftArmGeo = new THREE.BoxGeometry(0.24, 0.75, 0.24);
            const leftArmMat = this.createBoxMaterials(img, 32, 48, 4, 12, 4);
            const leftArm = new THREE.Mesh(leftArmGeo, leftArmMat);
            leftArm.position.set(-0.36, 1.125, 0);

            const headGeo = new THREE.BoxGeometry(0.4, 0.4, 0.4);
            const headMat = this.createBoxMaterials(img, 0, 0, 8, 8, 8);
            const head = new THREE.Mesh(headGeo, headMat);
            head.position.set(0, 1.7, 0);

            this.playerGroup.add(rightLeg, leftLeg, body, rightArm, leftArm, head);
            this.playerParts = { rightLeg, leftLeg, rightArm, leftArm, body, head };
            // Une texture manquante ne doit pas échouer silencieusement.
            this.playerGroup.visible = this.cameraMode !== 0;
        };
        img.onerror = () => console.error('Impossible de charger le skin du joueur : /static/textures/others/Paul.png');

        img.src = '/static/textures/others/Paul.png';
        this.playerGroup.visible = false;
        if (this.world?.scene) {
            this.world.scene.add(this.playerGroup);
        }
    }

    initControls() {
        const onKeyDown = (event) => {
            if (event.code === 'KeyE') {
                event.preventDefault();
                this.toggleInventory();
                return;
            }

            if (this.inventory.isOpen) return;

            switch (event.code) {
                case 'ShiftLeft':
                case 'ShiftRight':
                    this.isSprinting = true;
                    break;
                case 'KeyW': case 'KeyZ': this.moveForward = true; break;
                case 'KeyA': case 'KeyQ': this.moveLeft = true; break;
                case 'KeyS': this.moveBackward = true; break;
                case 'KeyD': this.moveRight = true; break;
                case 'Space':
                    event.preventDefault();
                    this.spaceHeld = true;
                    if (this.canJump) {
                        this.velocity.y = this.jumpForce;
                        this.canJump = false;
                        soundManager?.playJump?.();
                    }
                    break;
                case 'F3':
                case 'F5':
                    event.preventDefault();
                    this.toggleCameraMode();
                    break;
                default:
                    if (event.code.startsWith('Digit')) {
                        const num = parseInt(event.code.replace('Digit', ''), 10);
                        if (num >= 1 && num <= 9) {
                            this.inventory.selectSlot(num - 1);
                        }
                    }
                    break;
            }
        };

        const onKeyUp = (event) => {
            switch (event.code) {
                case 'ShiftLeft':
                case 'ShiftRight':
                    this.isSprinting = false;
                    break;
                case 'KeyW': case 'KeyZ': this.moveForward = false; break;
                case 'KeyA': case 'KeyQ': this.moveLeft = false; break;
                case 'KeyS': this.moveBackward = false; break;
                case 'KeyD': this.moveRight = false; break;
                case 'Space': this.spaceHeld = false; break;
            }
        };

        this.controls?.addEventListener('unlock', () => {
            this.moveForward = this.moveBackward = this.moveLeft = this.moveRight = this.spaceHeld = this.isSprinting = false;
        });

        window.addEventListener('wheel', (event) => {
            if (!this.controls?.isLocked || this.inventory.isOpen) return;
            const delta = Math.sign(event.deltaY);
            const nextSlot = (this.inventory.selectedSlotIndex + delta + HOTBAR_SIZE) % HOTBAR_SIZE;
            this.inventory.selectSlot(nextSlot);
        }, { passive: true });

        document.addEventListener('keydown', onKeyDown);
        document.addEventListener('keyup', onKeyUp);
    }

    toggleInventory() {
        if (!this.isReady) return;

        const nowOpen = this.inventory.toggleOpen();
        soundManager?.playInventoryToggle?.(nowOpen);

        window.dispatchEvent(new CustomEvent('inventory-toggle', { detail: { open: nowOpen } }));

        if (nowOpen) {
            if (this.controls?.isLocked) this.controls.unlock();
            this.moveForward = this.moveBackward = this.moveLeft = this.moveRight = this.isSprinting = false;
        }
    }

    toggleCameraMode() {
        this.cameraMode = (this.cameraMode + 1) % 3;
        if (this.playerGroup) this.playerGroup.visible = (this.cameraMode !== 0);

        
        
        
        
        // On conserve le pitch du regard : le réinitialiser à chaque changement
        // de vue faisait perdre l’orientation et donnait l’impression que la caméra
        // se bloquait ou sautait lors du passage en troisième personne.
    }

    testCollision(posX, posY, posZ) {
        if (!this.world) return null;

        const halfWidth = this.width / 2;
        const minX = Math.floor(posX - halfWidth);
        const maxX = Math.floor(posX + halfWidth);
        const minY = Math.floor(posY);
        const maxY = Math.floor(posY + this.height - 0.001);
        const minZ = Math.floor(posZ - halfWidth);
        const maxZ = Math.floor(posZ + halfWidth);

        const w = this.world;

        for (let x = minX; x <= maxX; x++) {
            for (let y = minY; y <= maxY; y++) {
                for (let z = minZ; z <= maxZ; z++) {
                    if (w.isSolidI(x, y, z)) {
                        return { x, y, z };
                    }
                }
            }
        }
        return null;
    }

    updateCameraPosition() {
        this.pivot.set(this.position.x, this.position.y + this.eyeHeight, this.position.z);

        
        
        
        this.camera.getWorldDirection(this.lookDir);
        // En vue avant, lookAt() fait regarder la caméra vers le joueur :
        // on inverse donc cette direction pour retrouver l'orientation du joueur au tick suivant.
        if (this.cameraMode === 2) this.lookDir.negate();

        if (this.cameraMode === 0) {
            this.controls?.getObject().position.copy(this.pivot);
        } else {
            this.pivot.y += 0.2;

            const dirFactor = (this.cameraMode === 1) ? -1 : 1;
            this.desiredPos.copy(this.pivot).addScaledVector(this.lookDir, dirFactor * this.thirdPersonDistance);

            const finalPos = this.raycastCameraCollision(this.pivot, this.desiredPos);
            this.controls?.getObject().position.copy(finalPos);

            if (this.cameraMode === 2) {
                
                
                
                
                this.camera.lookAt(this.pivot);
            } else {
                // Ne pas remettre la rotation à zéro en vue arrière : cela faisait perdre
                // le yaw/pitch et la caméra ne suivait plus correctement le regard du joueur.
            }
        }

        this.playerGroup.position.copy(this.position);

        const flat = this.tempFlatDir || (this.tempFlatDir = new THREE.Vector3());
        flat.copy(this.lookDir);
        flat.y = 0;
        if (flat.lengthSq() > 0) {
            flat.normalize();
            this.playerGroup.rotation.y = Math.atan2(flat.x, flat.z);
        }
    }

    raycastCameraCollision(from, to) {
        if (!this.world) return to;

        const fullDist = from.distanceTo(to);
        if (fullDist < 0.001) return to;

        this._camDir = this._camDir || new THREE.Vector3();
        const dir = this._camDir.copy(to).sub(from).normalize();
        const step = 0.1;
        const margin = 0.25;

        let travelled = 0;

        while (travelled < fullDist) {
            this.testPoint.copy(from).addScaledVector(dir, travelled);
            const isSolid = this.world.isSolid
                ? this.world.isSolid(this.testPoint.x, this.testPoint.y, this.testPoint.z)
                : this.world.hasBlock(this.testPoint.x, this.testPoint.y, this.testPoint.z);

            if (isSolid) {
                const safeDist = Math.max(0, travelled - margin);
                return this.tempRayPos.copy(from).addScaledVector(dir, safeDist);
            }
            travelled += step;
        }

        return to;
    }

    update(delta) {
        if (!this.isReady || this.dead) return;

        const dt = Math.min(delta, 0.05);
        this.attackSwing = Math.max(0, this.attackSwing - dt * 4.8);

        // Animation du corps : marche, respiration discrète et coup d'attaque.
        const horizontalSpeed = Math.hypot(this.velocity.x, this.velocity.z);
        const movingOnGround = this.canJump && horizontalSpeed > 0.08;
        if (movingOnGround) this.walkCycle += dt * (this.isSprinting ? 13 : 9);
        if (this.playerParts) {
            const swing = movingOnGround ? Math.sin(this.walkCycle) * (this.isSprinting ? 0.72 : 0.48) : 0;
            const idle = Math.sin(performance.now() * 0.0018) * 0.025;
            this.playerParts.rightLeg.rotation.x = swing;
            this.playerParts.leftLeg.rotation.x = -swing;
            const attackPose = Math.sin((1 - this.attackSwing) * Math.PI) * this.attackSwing * 1.35;
            this.playerParts.rightArm.rotation.x = -swing * 0.8 + idle - attackPose;
            this.playerParts.leftArm.rotation.x = swing * 0.8 - idle;
            this.playerParts.body.rotation.z = (movingOnGround ? Math.sin(this.walkCycle * 2) * 0.025 : 0) - attackPose * 0.08;
        }

        if (this.canJump) this.fallPeakY = Math.max(this.fallPeakY, this.position.y);
        
        if (this.isSprinting && this.moveForward) {
            this.speed = this.sprintSpeed;
        } else {
            this.speed = this.walkSpeed;
        }

        this.forward.set(0, 0, 0);
        if (this.controls?.isLocked && !this.inventory.isOpen) {
            this.camera.getWorldDirection(this.forward);
            this.forward.y = 0;
            this.forward.normalize();

            this.side.crossVectors(this.forward, this.upVector).normalize();

            this.moveVector.set(0, 0, 0);
            if (this.moveForward) this.moveVector.add(this.forward);
            if (this.moveBackward) this.moveVector.sub(this.forward);
            if (this.moveRight) this.moveVector.add(this.side);
            if (this.moveLeft) this.moveVector.sub(this.side);

            if (this.moveVector.lengthSq() > 0) {
                this.moveVector.normalize().multiplyScalar(this.speed);
            }

            this.velocity.x = this.moveVector.x;
            this.velocity.z = this.moveVector.z;
        } else {
            this.velocity.x = 0;
            this.velocity.z = 0;
        }

        const inWater = this.world.isFluidAt(this.position.x, this.position.y + 0.5, this.position.z);
        if (inWater) {
            const headInWater = this.world.isFluidAt(this.position.x, this.position.y + this.eyeHeight, this.position.z);
            this.velocity.x *= 0.6;
            this.velocity.z *= 0.6;
            if (this.spaceHeld) {
                this.velocity.y = headInWater ? 3.5 : 5.5;
            } else {
                this.velocity.y = Math.max(this.velocity.y - this.gravity * 0.25 * dt, -3.0);
            }
        } else {
            this.velocity.y -= this.gravity * dt;
        }

        const halfWidth = this.width / 2;

        this.position.x += this.velocity.x * dt;
        let block = this.testCollision(this.position.x, this.position.y, this.position.z);
        if (block) {
            this.position.x = this.velocity.x > 0 ? block.x - halfWidth - 0.001 : block.x + 1 + halfWidth + 0.001;
            this.velocity.x = 0;
        }

        this.position.z += this.velocity.z * dt;
        block = this.testCollision(this.position.x, this.position.y, this.position.z);
        if (block) {
            this.position.z = this.velocity.z > 0 ? block.z - halfWidth - 0.001 : block.z + 1 + halfWidth + 0.001;
            this.velocity.z = 0;
        }

        const velocityBeforeY = this.velocity.y;
        this.position.y += this.velocity.y * dt;
        block = this.testCollision(this.position.x, this.position.y, this.position.z);
        if (block) {
            if (this.velocity.y < 0) {
                const fallDistance = Math.max(0, this.fallPeakY - (block.y + 1));
                this.position.y = block.y + 1;
                this.velocity.y = 0;
                if (!this.canJump && velocityBeforeY < -6) {
                    soundManager?.playLand?.(Math.min(1.5, Math.abs(velocityBeforeY) / 12));
                }
                // Environ 3 blocs de chute sont sans danger ; ensuite les dégâts montent.
                if (!this.canJump && !this.world.isFluidAt(this.position.x, this.position.y - 0.1, this.position.z) && fallDistance > 3.2) {
                    this.takeDamage(Math.max(1, Math.floor(fallDistance - 3)));
                }
                this.fallPeakY = this.position.y;
                this.canJump = true;
            } else if (this.velocity.y > 0) {
                this.position.y = block.y - this.height - 0.001;
                this.velocity.y = 0;
            }
        } else {
            this.canJump = false;
        }

        if ((Math.abs(this.velocity.x) > 0 || Math.abs(this.velocity.z) > 0) && this.canJump) {
            this.stepTimer += dt;
            const stepInterval = (this.isSprinting && this.moveForward) ? 0.22 : 0.35;
            if (this.stepTimer > stepInterval) {
                if (typeof soundManager !== 'undefined' && soundManager?.playStep) {
                    const blockUnderId = this.world.getBlock(
                        Math.floor(this.position.x),
                        Math.floor(this.position.y - 0.1),
                        Math.floor(this.position.z)
                    );
                    soundManager.playStep(blockUnderId);
                }
                this.stepTimer = 0;
            }
        }

        if (this.position.y < -5) {
            const currentX = Math.floor(this.position.x);
            const currentZ = Math.floor(this.position.z);
            let highestY = this.world.getTerrainHeight ? this.world.getTerrainHeight(currentX, currentZ) : 64;

            for (let y = 255; y >= highestY; y--) {
                if (this.world.hasBlock(currentX, y, currentZ)) {
                    highestY = y;
                    break;
                }
            }
            this.position.y = highestY + 2.0;
            this.velocity.set(0, 0, 0);
        }

        this.updateCameraPosition();
    }
}